package com.intandif.twowayseekbar;

public class Rs {

    private Rs() {
    }
    public static final class color {
        private color() {
        }

        public static final int trackHighlightTintColor = 0x7f0500b4;
        public static final int trackTintColor = 0x7f0500b5;
    }

    public static final class dimen {
        private dimen() {
        }

        public static final int displayTextBasicOffsetY = 0x7f060088;
        public static final int displayTextFontSize = 0x7f060089;
        public static final int thumbOutlineSize = 0x7f0600e3;
        public static final int thumbRadius = 0x7f0600e4;
        public static final int trackHeight = 0x7f0600ed;
    }

    public static final class styleable {
        private styleable() {
        }

        public static final int[] RangeSliderView = {0x7f0300b6, 0x7f030224, 0x7f030225, 0x7f030240, 0x7f030241, 0x7f030243};
        public static final int RangeSliderView_displayTextFontSize = 0;
        public static final int RangeSliderView_thumbOutlineSize = 1;
        public static final int RangeSliderView_thumbRadius = 2;
        public static final int RangeSliderView_trackHeight = 3;
        public static final int RangeSliderView_trackHighlightTintColor = 4;
        public static final int RangeSliderView_trackTintColor = 5;

    }
}
